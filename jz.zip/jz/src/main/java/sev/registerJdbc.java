package sev;
import java.sql.*;
public class registerJdbc {
	
	//private static String driverName="com.mysql.cj.jdbc.Driver";
	//private static String dbURL="jdbc:mysql://localhost:3306/userdata?serverTimezone=UTC&useUnicode=true&characterEncoding=utf-8";
	//private static String userName="root";
	//private static String userPwd="mysql";
	
	private static String driver="com.mysql.cj.jdbc.Driver";//���ݿ�����������Ӧ���ַ���
	private static String URL="jdbc:mysql://localhost:3306/userdata?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false";
	public boolean userregister(String username,String password){
		boolean Re = false;
		Connection conn=null;
		String sql = "select * from user where username='"+username+"'";
		// String sql = "select * from [user] where id=?";
		try{
			Class.forName(driver);
			conn=DriverManager.getConnection(URL,"root","mysql");//���������ݿ�����ӣ������ر�ʾ���ӵ�Connection����
			Statement stm = conn.createStatement();
			ResultSet rs = stm.executeQuery(sql);
			if(!rs.next()){
				sql = "insert into user(username,password) values('"+username+"','"+password+"')";
				stm.execute(sql);
				Re = true;
			}
			rs.close();
			stm.close();
			conn.close();
		}catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
		}
		return Re;
	}
	/*public static void main(String[] args) {
		 registerJdbc rg=new registerJdbc();
		 Boolean b=rg.userregister("11","111");
		 if(b) {
			 System.out.print("1");
		 }
		 else {
			 System.out.print("0");
		 }
		 
	}*/
	
}
