package sev;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

/**
 * Servlet implementation class log
 */
public class log extends HttpServlet {
	private static final long serialVersionUID = 1L;
    final String user="dear";
    final String psw="111";
    /**
     * @see HttpServlet#HttpServlet()
     */
    public log() {
        super();
        // TODO Auto-generated constructor stub
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		/*String username=request.getParameter("username");
		String password=request.getParameter("password");
		String checkcode=request.getParameter("checkCode");
		String ccode=(String)request.getSession().getAttribute("scode");
		*/
		 /*PrintWriter out = response.getWriter();
			if(checkcode.equals("")||checkcode==null){
				out.print("<script>alert('��������֤��');window.location.href('index.jsp')</script>");
			}else{
				if(!checkcode.equalsIgnoreCase(checkcode)){
					out.print("<script>alert('��֤�벻��ȷ,����������');history.back(-1);</script>");
				}else{
					out.print("��¼�ɹ�");
				}
			}*/
		
			boolean b=false;
			loginJdbc login=new loginJdbc();//�½�����
			
			String username=request.getParameter("username");
			String password=request.getParameter("password");
			String result="";
			
			try {
				b=login.isuserlogin(username, password);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(b){
				response.sendRedirect("index.jsp");
			}else{
				response.sendRedirect("faile.jsp");
			}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
